<?php

	echo  "Hello world";

?>